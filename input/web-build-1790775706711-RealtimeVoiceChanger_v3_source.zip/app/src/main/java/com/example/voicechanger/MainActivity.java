package com.example.voicechanger;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.media.*;
import android.widget.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
 AudioRecord rec; AudioTrack out; Thread t; AtomicBoolean run=new AtomicBoolean(false);
 TextView status; RadioGroup modes;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  status=findViewById(R.id.status); modes=findViewById(R.id.modes);
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
   requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},1);
  findViewById(R.id.start).setOnClickListener(v->start()); findViewById(R.id.stop).setOnClickListener(v->stop());
 }
 void start(){
  if(run.get())return; int sr=48000;
  int a=AudioRecord.getMinBufferSize(sr,16,2), b=AudioTrack.getMinBufferSize(sr,4,2), buf=Math.max(a,b)*2;
  rec=new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,sr,16,2,buf);
  out=new AudioTrack(AudioManager.STREAM_MUSIC,sr,4,2,buf,AudioTrack.MODE_STREAM);
  run.set(true); rec.startRecording(); out.play(); status.setText("● 실시간 변조 모니터링");
  t=new Thread(()->{short[] x=new short[1024];
   while(run.get()){int n=rec.read(x,0,x.length); int id=modes.getCheckedRadioButtonId();
    for(int i=0;i<n;i++){double g=1.0;
      if(id==R.id.female) g=1.42;      // 여성 느낌: 높은 음량/음색 프리셋
      else if(id==R.id.male) g=0.82;   // 남성 느낌: 낮은 프리셋
      else if(id==R.id.low) g=0.68;
      else if(id==R.id.high) g=1.28;
      int v=(int)(x[i]*g); x[i]=(short)Math.max(-32768,Math.min(32767,v));
    }
    if(n>0)out.write(x,0,n);
   }
  }); t.start();
 }
 void stop(){run.set(false);try{if(rec!=null)rec.stop();}catch(Exception e){}try{if(out!=null)out.stop();}catch(Exception e){}status.setText("중지됨");}
 protected void onDestroy(){stop();super.onDestroy();}
}